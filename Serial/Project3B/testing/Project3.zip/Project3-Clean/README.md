Velocity Verlet Algorithm implemented in the `Sim` class which is declared in `include/sim.h` and its function definitions are in `src/sim.cxx`.

To run script `main.cxx`:

```{bash}
cd build
cmake ..
make
./scripts/main
```